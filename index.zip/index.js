const express = require('express');
const mongoose = require('mongoose');

// Connect to MongoDB
mongoose.connect('mongodb+srv://tamilguhan50:tamil75@learnnodejs.geuon4w.mongodb.net/?retryWrites=true&w=majority&appName=learnNodejs', {

}
);
mongoose.connection.on('connected', () => {
    console.log('Connected to MongoDB');
  });

const app = express();
const data=[]
// Middleware to parse JSON bodies
app.use(express.json());

// Define routes
app.get('/', async (req, res) => {
    res.send(data)
 
});
app.post("/add",(req,res)=>{
    let x=req.body;
    data.push(x);
    res.send({statusCode:' 1'})



})
app.put("/put/:name",(req,res)=>{
    let y= req.params.name.body
    res.send(`got it ${ y} `)

})



// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is listening on port ${PORT}`);
});
